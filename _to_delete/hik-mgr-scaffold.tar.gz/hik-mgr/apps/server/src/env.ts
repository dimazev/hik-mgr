import 'dotenv/config';

function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (value === undefined) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT || 4000),
  // Falls back to an insecure default so local `yarn dev` works out of the
  // box, but anyone deploying for real should set a proper APP_SECRET in
  // .env — see .env.example.
  appSecret: required('APP_SECRET', 'dev-only-insecure-secret-change-me'),
  dbPath: process.env.DB_PATH || './data/hik-mgr.sqlite',
};
